import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform, useSpring, useMotionTemplate } from 'framer-motion';

// --- CUSTOM SVG LOGO ---
function SynapseXLogo({ className = 'w-4 h-4 text-white' }: { className?: string }) {
  const pathD =
    'M 1.5,23 L 1.5,33 C 1.5,38.5 6,43 11.5,43 L 16.5,43 C 22,43 26.5,38.5 26.5,33 Q 28,28 33,26.5 C 38.5,26.5 43,22 43,16.5 L 43,11.5 C 43,6 38.5,1.5 33,1.5 L 23,1.5 Q 12,12 1.5,23 Z';

  return (
    <svg viewBox="-50 -50 100 100" className={className} fill="currentColor">
      <g>
        <path d={pathD} />
        <path d={pathD} transform="rotate(90)" />
        <path d={pathD} transform="rotate(180)" />
        <path d={pathD} transform="rotate(270)" />
      </g>
    </svg>
  );
}

// --- SCRAMBLE IN ANIMATION ---
function ScrambleIn({
  text,
  delay = 0,
  triggered = false,
  className = '',
}: {
  text: string;
  delay?: number;
  triggered?: boolean;
  className?: string;
}) {
  const [displayText, setDisplayText] = useState('');
  const [isStarted, setIsStarted] = useState(false);
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+~|}{[]:;?><';

  useEffect(() => {
    if (!triggered) return;

    const timer = setTimeout(() => {
      setIsStarted(true);
      let frame = 0;
      const totalFrames = text.length * 2;

      const interval = setInterval(() => {
        frame++;
        const revealedCount = Math.floor(frame / 2);
        let result = '';

        for (let i = 0; i < text.length; i++) {
          if (text[i] === ' ') {
            result += ' ';
          } else if (i < revealedCount) {
            result += text[i];
          } else if (i < revealedCount + 3) {
            result += chars[Math.floor(Math.random() * chars.length)];
          } else {
            result += '';
          }
        }

        setDisplayText(result);

        if (frame >= totalFrames) {
          clearInterval(interval);
          setDisplayText(text);
        }
      }, 25);

      return () => clearInterval(interval);
    }, delay);

    return () => clearTimeout(timer);
  }, [triggered, text, delay]);

  if (!isStarted) {
    return <span className={className}>&nbsp;</span>;
  }

  return <span className={className}>{displayText}</span>;
}

// --- HOVER SCRAMBLE TEXT ---
function ScrambleText({
  text,
  isHovered,
  className = '',
}: {
  text: string;
  isHovered: boolean;
  className?: string;
}) {
  const [displayText, setDisplayText] = useState(text);
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+~|}{[]:;?><';

  useEffect(() => {
    if (!isHovered) {
      setDisplayText(text);
      return;
    }

    let frame = 0;
    const totalFrames = text.length * 4;

    const interval = setInterval(() => {
      frame++;
      const revealedCount = Math.floor(frame / 4);
      let result = '';

      for (let i = 0; i < text.length; i++) {
        if (text[i] === ' ') {
          result += ' ';
        } else if (i < revealedCount) {
          result += text[i];
        } else {
          result += chars[Math.floor(Math.random() * chars.length)];
        }
      }

      setDisplayText(result);

      if (frame >= totalFrames) {
        clearInterval(interval);
        setDisplayText(text);
      }
    }, 25);

    return () => clearInterval(interval);
  }, [isHovered, text]);

  return <span className={className}>{displayText}</span>;
}

// --- SQUASH HAMBURGER ICON ---
function SquashHamburger({ isOpen, isMobile = false }: { isOpen: boolean; isMobile?: boolean }) {
  return (
    <div className={`relative flex flex-col justify-between ${isMobile ? 'w-[15px] h-[10px]' : 'w-[18px] h-[12px]'}`}>
      <motion.span
        animate={
          isOpen
            ? { rotate: 45, y: isMobile ? 4.4 : 5.25 }
            : { rotate: 0, y: 0 }
        }
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        className={`w-full bg-white block origin-center ${isMobile ? 'h-[1.2px]' : 'h-[1.5px]'}`}
      />
      <motion.span
        animate={isOpen ? { opacity: 0, scale: 0.5 } : { opacity: 1, scale: 1 }}
        transition={{ duration: 0.15 }}
        className={`w-full bg-white block ${isMobile ? 'h-[1.2px]' : 'h-[1.5px]'}`}
      />
      <motion.span
        animate={
          isOpen
            ? { rotate: -45, y: isMobile ? -4.4 : -5.25 }
            : { rotate: 0, y: 0 }
        }
        transition={{ type: 'spring', stiffness: 300, damping: 20 }}
        className={`w-full bg-white block origin-center ${isMobile ? 'h-[1.2px]' : 'h-[1.5px]'}`}
      />
    </div>
  );
}

interface CardData {
  id: number;
  title: string;
  value: string;
  badge: string;
  desc: string;
  detail: string;
  stats: { label: string; val: string }[];
}

export default function App() {
  const [entranceComplete, setEntranceComplete] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [downloadHovered, setDownloadHovered] = useState(false);
  const [aboutHovered, setAboutHovered] = useState(false);
  const [metricsHovered, setMetricsHovered] = useState(false);
  const [selectedCard, setSelectedCard] = useState<CardData | null>(null);

  // Mouse scrub state for Hero Video
  const heroVideoRef = useRef<HTMLVideoElement>(null);
  const isSeekingRef = useRef(false);
  const pendingSeekRef = useRef<number | null>(null);

  // Framer Motion scroll tracking for Section 2 (3D Text)
  const section2Ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress: s2Progress } = useScroll({
    target: section2Ref,
    offset: ['start end', 'end start'],
  });

  const smoothS2Progress = useSpring(s2Progress, {
    stiffness: 15,
    damping: 32,
    mass: 1.8,
  });

  const yScaleValue = useTransform(smoothS2Progress, [0, 1], [30, -60]);
  const textOpacity = useTransform(smoothS2Progress, [0.2, 0.45], [0, 1]);
  const transformStyle = useMotionTemplate`perspective(400px) rotateX(8deg) translateY(${yScaleValue}px) translateZ(10px)`;

  // Hero entrance trigger
  useEffect(() => {
    const timer = setTimeout(() => {
      setEntranceComplete(true);
    }, 800);
    return () => clearTimeout(timer);
  }, []);

  // Mouse scrub handler for Video #1
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = heroVideoRef.current;
    if (!video || !video.duration) return;

    const deltaX = e.movementX;
    const seekDelta = (deltaX / window.innerWidth) * video.duration * 0.8;
    const targetTime = Math.max(0, Math.min(video.duration, video.currentTime + seekDelta));

    if (isSeekingRef.current) {
      pendingSeekRef.current = targetTime;
    } else {
      isSeekingRef.current = true;
      video.currentTime = targetTime;
    }
  };

  const handleSeeked = () => {
    const video = heroVideoRef.current;
    if (pendingSeekRef.current !== null && video) {
      const nextTime = pendingSeekRef.current;
      pendingSeekRef.current = null;
      video.currentTime = nextTime;
    } else {
      isSeekingRef.current = false;
    }
  };

  const scrollToSection = (offsetFactor: number) => {
    window.scrollTo({
      top: window.innerHeight * offsetFactor,
      behavior: 'smooth',
    });
    setIsMenuOpen(false);
  };

  const cardsData: CardData[] = [
    {
      id: 1,
      title: 'Synaptic Latency',
      value: '2.4ms',
      badge: 'REAL-TIME FEEDBACK',
      desc: 'Sub-millisecond bio-synaptic transmission speed across active cortical clusters.',
      detail: '99.98% zero-loss pathway mapping',
      stats: [
        { label: 'Transmission Speed', val: '2.4 ms' },
        { label: 'Cortical Sync', val: '99.98%' },
        { label: 'Jitter Variance', val: '0.04 ms' },
        { label: 'Channel Protocol', val: 'Bio-Bus v4' },
      ],
    },
    {
      id: 2,
      title: 'Signal Accuracy',
      value: '99.7%',
      badge: 'NOISE ISOLATION',
      desc: 'Real-time noise filtering separating biological artifacts from cognitive intent.',
      detail: 'Dynamic artifact suppression',
      stats: [
        { label: 'SNR Isolation', val: '+42 dB' },
        { label: 'Artifact Filter', val: 'Active' },
        { label: 'Confidence Index', val: '99.7%' },
        { label: 'Sampling Rate', val: '10 kHz' },
      ],
    },
    {
      id: 3,
      title: 'Neural Parameters',
      value: '140B',
      badge: 'ADAPTIVE MODEL',
      desc: 'Continuous deep-learning weight alignment mapping physiological states.',
      detail: '72-hr neural baseline sync',
      stats: [
        { label: 'Active Parameters', val: '140 Billion' },
        { label: 'Quantization', val: 'FP16 Precision' },
        { label: 'Context Horizon', val: '128k Tokens' },
        { label: 'Baseline Lock', val: '72 Hours' },
      ],
    },
    {
      id: 4,
      title: 'Synaptic Bandwidth',
      value: '1.2 TB/s',
      badge: 'ULTRA-HIGH THROUGHPUT',
      desc: 'Ultra-high bandwidth bio-digital interface link for zero-friction loop feedback.',
      detail: 'Multi-threaded cortical stream',
      stats: [
        { label: 'Data Throughput', val: '1.2 TB/sec' },
        { label: 'Parallel Threads', val: '256 Cores' },
        { label: 'Buffer Overhead', val: '< 0.01%' },
        { label: 'PCIe Gen 5 Bridge', val: 'Active' },
      ],
    },
  ];

  return (
    <div className="w-full bg-black text-white selection:bg-white selection:text-black font-sans relative overflow-x-hidden">
      {/* FIXED NAVBAR */}
      <motion.nav
        initial={{ opacity: 0 }}
        animate={{ opacity: entranceComplete ? 1 : 0 }}
        transition={{ duration: 0.8 }}
        className="fixed top-0 left-0 right-0 h-20 z-50 px-4 sm:px-6 md:px-8 flex items-center justify-between pointer-events-none"
      >
        {/* DESKTOP NAVBAR (hidden md:flex) */}
        <div className="hidden md:flex items-center gap-2 pointer-events-auto">
          {/* Logo Pill */}
          <motion.div
            whileHover={{ scale: 1.02, backgroundColor: 'rgba(255, 255, 255, 0.22)' }}
            whileTap={{ scale: 0.98 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className={`h-12 px-5 bg-white/15 backdrop-blur-md rounded-[14px] flex items-center gap-3 cursor-pointer transition-colors ${
              isMenuOpen ? 'hidden md:flex' : 'flex'
            }`}
          >
            <SynapseXLogo className="w-4 h-4 text-white" />
            <span className="text-base font-medium tracking-tight text-white">SynapseX</span>
          </motion.div>

          {/* Expanding Menu Pill */}
          <motion.div
            animate={{ width: isMenuOpen ? 290 : 48 }}
            transition={{ type: 'spring', stiffness: 350, damping: 28 }}
            className="h-12 bg-white/15 backdrop-blur-md rounded-[14px] overflow-hidden flex items-center relative"
          >
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`flex items-center justify-center transition-colors focus:outline-none cursor-pointer ${
                isMenuOpen
                  ? 'w-9 h-9 rounded-[11px] bg-white/10 hover:bg-white/20 ml-1.5'
                  : 'w-12 h-12'
              }`}
              aria-label="Toggle menu"
            >
              <SquashHamburger isOpen={isMenuOpen} />
            </button>

            {isMenuOpen && (
              <motion.div
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.25 }}
                className="flex items-center gap-6 ml-4"
              >
                <button
                  onMouseEnter={() => setAboutHovered(true)}
                  onMouseLeave={() => setAboutHovered(false)}
                  onClick={() => scrollToSection(1)}
                  className="text-base font-normal text-white/85 hover:text-white transition-colors focus:outline-none cursor-pointer"
                >
                  <ScrambleText text="About" isHovered={aboutHovered} />
                </button>
                <button
                  onMouseEnter={() => setMetricsHovered(true)}
                  onMouseLeave={() => setMetricsHovered(false)}
                  onClick={() => scrollToSection(2)}
                  className="text-base font-normal text-white/85 hover:text-white transition-colors focus:outline-none cursor-pointer"
                >
                  <ScrambleText text="Metrics" isHovered={metricsHovered} />
                </button>
              </motion.div>
            )}
          </motion.div>
        </div>

        {/* MOBILE NAVBAR (md:hidden) */}
        <div className="flex md:hidden items-center gap-2 pointer-events-auto">
          <motion.div
            animate={{ width: isMenuOpen ? 0 : 'auto', opacity: isMenuOpen ? 0 : 1 }}
            transition={{ type: 'spring', stiffness: 350, damping: 28 }}
            className="overflow-hidden"
          >
            <div
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="h-9 px-3.5 bg-white/15 backdrop-blur-md rounded-[10px] flex items-center gap-2 cursor-pointer"
            >
              <SynapseXLogo className="w-3.5 h-3.5 text-white" />
              <span className="text-xs font-medium tracking-tight text-white whitespace-nowrap">SynapseX</span>
            </div>
          </motion.div>

          <motion.div
            animate={{ width: isMenuOpen ? '100%' : 36 }}
            transition={{ type: 'spring', stiffness: 350, damping: 28 }}
            className="h-9 bg-white/15 backdrop-blur-md rounded-[10px] overflow-hidden flex items-center"
          >
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="w-9 h-9 flex items-center justify-center focus:outline-none cursor-pointer shrink-0"
              aria-label="Toggle menu"
            >
              <SquashHamburger isOpen={isMenuOpen} isMobile />
            </button>

            {isMenuOpen && (
              <div className="flex items-center gap-4 ml-2 pr-4">
                <button
                  onClick={() => scrollToSection(1)}
                  className="text-xs font-normal text-white/85 hover:text-white whitespace-nowrap focus:outline-none cursor-pointer"
                >
                  About
                </button>
                <button
                  onClick={() => scrollToSection(2)}
                  className="text-xs font-normal text-white/85 hover:text-white whitespace-nowrap focus:outline-none cursor-pointer"
                >
                  Metrics
                </button>
              </div>
            )}
          </motion.div>
        </div>

        {/* DOWNLOAD BUTTON (RIGHT) */}
        <motion.button
          whileHover={{ scale: 1.03, backgroundColor: '#e2e2e6' }}
          whileTap={{ scale: 0.97 }}
          onMouseEnter={() => setDownloadHovered(true)}
          onMouseLeave={() => setDownloadHovered(false)}
          className="h-9 sm:h-12 px-3.5 sm:px-6 bg-white rounded-full text-black font-medium text-xs sm:text-sm flex items-center gap-2 pointer-events-auto cursor-pointer focus:outline-none shadow-lg"
        >
          <i className="bi bi-apple text-base sm:text-lg" />
          <ScrambleText text="Download" isHovered={downloadHovered} />
        </motion.button>
      </motion.nav>

      {/* SECTION 1: HERO (MOUSE-SCRUBBED VIDEO #1) */}
      <section
        onMouseMove={handleMouseMove}
        className="w-full h-screen h-[100dvh] relative overflow-hidden flex flex-col justify-between select-none bg-black"
      >
        {/* Background Video #1 */}
        <video
          ref={heroVideoRef}
          onSeeked={handleSeeked}
          playsInline
          muted
          preload="auto"
          className="absolute inset-0 w-full h-full object-cover pointer-events-none"
          src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260622_083515_290e5a10-0b95-41af-a5e2-32b6389baa4d.mp4"
        />

        {/* Dot Grid Overlay */}
        <div
          className="absolute inset-0 pointer-events-none opacity-5"
          style={{
            backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)',
            backgroundSize: '24px 24px',
          }}
        />

        {/* Background Watermark Text "TRANSCENDENCE" */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden">
          <span
            className="font-black uppercase tracking-[-4px] text-transparent select-none opacity-10"
            style={{
              fontFamily: '"Anton SC", sans-serif',
              fontSize: 'clamp(120px, 30vw, 521px)',
              transform: 'translateY(50px)',
              backgroundImage: 'radial-gradient(circle, rgba(142,127,148,0) 0%, #8E7F94 70%)',
              WebkitBackgroundClip: 'text',
            }}
          >
            TRANSCENDENCE
          </span>
        </div>

        {/* Bottom Seamless Gradient Transition to Section 2 */}
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-black via-black/60 to-transparent pointer-events-none z-10" />

        {/* Spacer pushing content to bottom */}
        <div className="flex-1" />

        {/* Bottom Hero Row */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: entranceComplete ? 1 : 0 }}
          transition={{ duration: 1.0 }}
          className="relative z-20 px-4 sm:px-6 md:px-8 pt-20 sm:pt-24 pb-8 sm:pb-12 flex flex-col md:flex-row md:items-end md:justify-between gap-6"
        >
          {/* Left Column */}
          <div className="flex flex-col gap-4">
            <h1 className="text-white font-light leading-[0.95] tracking-[-0.03em] text-[clamp(40px,10vw,100px)]">
              <ScrambleIn text="Brain" delay={200} triggered={entranceComplete} />
              <br />
              <ScrambleIn text="And Body" delay={500} triggered={entranceComplete} />
            </h1>

            <motion.p
              initial={{ y: 25, opacity: 0 }}
              animate={
                entranceComplete
                  ? { y: 0, opacity: 1 }
                  : { y: 25, opacity: 0 }
              }
              transition={{
                duration: 0.9,
                delay: 0.2,
                ease: [0.215, 0.61, 0.355, 1.0],
              }}
              className="max-w-sm text-[13px] sm:text-[15px] text-white/60 leading-relaxed font-normal"
            >
              Built at the intersection of neuroscience and artificial intelligence. SynapseX continuously maps neural pathways, cognitive load, and physiological states into a single adaptive intelligence layer.
            </motion.p>
          </div>

          {/* Right Column h1 */}
          <h1 className="text-left md:text-right text-white font-light leading-[0.95] tracking-[-0.03em] text-[clamp(40px,10vw,100px)]">
            <ScrambleIn text="One" delay={700} triggered={entranceComplete} />
            <br />
            <ScrambleIn text="Network" delay={1000} triggered={entranceComplete} />
          </h1>
        </motion.div>
      </section>

      {/* SECTION 2: PROMINENT CENTERED STORY LAYOUT (CHARACTER VIDEO CENTERED + STORY CARD CENTERED) */}
      <section
        ref={section2Ref}
        className="w-full min-h-screen relative overflow-hidden py-28 sm:py-36 px-6 bg-black flex items-center justify-center"
      >
        <div className="max-w-4xl mx-auto w-full flex flex-col items-center text-center space-y-10 z-20">
          {/* Centered Character Video Frame */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.0 }}
            viewport={{ once: true, amount: 0.3 }}
            className="w-full max-w-2xl rounded-3xl overflow-hidden border border-white/25 shadow-[0_0_90px_rgba(255,255,255,0.22)] group"
          >
            <div className="w-full h-[400px] sm:h-[480px] relative overflow-hidden">
              <video
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260622_092455_089c54f8-3b03-4966-9df1-e9746063d0ef.mp4"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-xs text-white/80 font-mono">
                <span>CHAPTER I // SYNAPSE CORE</span>
                <span>NEURAL V2.4</span>
              </div>
            </div>
          </motion.div>

          {/* Centered Story Card */}
          <motion.div
            style={{
              transform: transformStyle,
              opacity: textOpacity,
            }}
            className="w-full bg-black/80 backdrop-blur-2xl border border-white/20 rounded-3xl p-8 sm:p-12 md:p-14 text-center shadow-2xl space-y-6"
          >
            <div className="flex items-center justify-center gap-2 text-xs sm:text-sm text-white/40 tracking-[0.2em] uppercase font-mono">
              <span className="w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
              <span>Chapter I: The Synaptic Awakening</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-white leading-tight tracking-tight max-w-3xl mx-auto">
              Translating Thought into Computational Reality
            </h2>

            <p className="text-white/60 text-base sm:text-lg leading-relaxed font-normal max-w-2xl mx-auto">
              A neural-AI interface built on the architecture of the human nervous system. SynapseX translates synaptic activity into computational intelligence. Every signal becomes measurable, structured, and visible. It continuously reconstructs internal state as a dynamic neural map.
            </p>

            <div className="pt-6 border-t border-white/10 flex flex-wrap items-center justify-center gap-6 text-sm sm:text-base text-white/90 font-mono">
              <div className="flex items-center gap-2">
                <span className="text-emerald-400">✓</span>
                <span>Sub-millisecond Bio-Translation</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400">✓</span>
                <span>Bio-Electric Noise Cancellation</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-emerald-400">✓</span>
                <span>Direct Cortical Quantum Bus</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* SECTION 3: CENTERED STORY & INTERACTIVE TELEMETRY CARDS (CHARACTER VIDEO CENTERED + CARDS CENTERED) */}
      <section className="w-full min-h-screen relative overflow-hidden py-28 sm:py-36 px-6 bg-black flex items-center justify-center">
        <div className="max-w-4xl mx-auto w-full flex flex-col items-center text-center space-y-10 z-20">
          {/* Centered Character Video Frame */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.0 }}
            viewport={{ once: true, amount: 0.3 }}
            className="w-full max-w-2xl rounded-3xl overflow-hidden border border-white/25 shadow-[0_0_90px_rgba(255,255,255,0.22)] group"
          >
            <div className="w-full h-[400px] sm:h-[480px] relative overflow-hidden">
              <video
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260622_095810_ecea3dd2-fc5e-4e41-8696-4219290b6589.mp4"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-xs text-white/80 font-mono">
                <span>CHAPTER II // QUANTUM MATRIX</span>
                <span>140B PARAMETERS</span>
              </div>
            </div>
          </motion.div>

          {/* Centered Story Header */}
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-2 text-xs sm:text-sm text-white/40 tracking-[0.2em] uppercase font-mono">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Chapter II: Quantum Bio-Telemetry</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-white leading-tight tracking-tight">
              Unrivaled Latency & Signal Precision
            </h2>
            <p className="text-white/60 text-base sm:text-lg leading-relaxed font-normal max-w-2xl mx-auto">
              Operating at 2.4ms latency with 99.7% signal precision. Click any card below to launch the macOS Telemetry OS window!
            </p>
          </div>

          {/* Centered 4 Interactive Neural Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 w-full text-left pt-2">
            {cardsData.map((card) => (
              <motion.div
                key={card.id}
                onClick={() => setSelectedCard(card)}
                whileHover={{ scale: 1.05, backgroundColor: 'rgba(255,255,255,0.08)' }}
                className="bg-white/[0.05] border border-white/20 rounded-2xl p-6 sm:p-7 cursor-pointer hover:border-white/60 transition-all shadow-xl group"
              >
                <div className="text-xs text-white/40 font-mono mb-2 flex items-center justify-between">
                  <span>{card.badge}</span>
                  <span className="text-white/30">0{card.id}</span>
                </div>
                <div className="text-3xl sm:text-4xl font-light text-white mb-2 group-hover:text-emerald-400 transition-colors">
                  {card.value}
                </div>
                <div className="text-sm font-semibold text-white/90 mb-1">{card.title}</div>
                <p className="text-xs text-white/50 leading-relaxed mb-3">{card.desc}</p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-emerald-400 font-mono flex items-center justify-between">
                  <span>Launch macOS Window</span>
                  <span className="group-hover:translate-x-1 transition-transform">↗</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* APPLE MACOS OS STYLE EXPANDED WINDOW MODAL */}
      <AnimatePresence>
        {selectedCard && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedCard(null)}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/80 backdrop-blur-md cursor-pointer"
          >
            {/* macOS Window Frame */}
            <motion.div
              initial={{ scale: 0.85, y: 30, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.85, y: 30, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 350, damping: 25 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-2xl bg-[#0D0D11]/90 backdrop-blur-2xl border border-white/20 rounded-2xl shadow-[0_0_80px_rgba(255,255,255,0.2)] overflow-hidden text-white font-mono cursor-default relative"
            >
              {/* macOS Window Title Bar */}
              <div className="h-11 px-4 bg-white/[0.06] border-b border-white/10 flex items-center justify-between select-none">
                {/* Traffic Light Buttons */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSelectedCard(null)}
                    className="w-3 h-3 rounded-full bg-[#FF5F56] hover:opacity-80 transition-opacity flex items-center justify-center group cursor-pointer"
                    title="Close"
                  >
                    <span className="opacity-0 group-hover:opacity-100 text-[8px] font-bold text-black">×</span>
                  </button>
                  <div className="w-3 h-3 rounded-full bg-[#FFBD2E]" />
                  <div className="w-3 h-3 rounded-full bg-[#27C93F]" />
                </div>

                {/* macOS Title */}
                <div className="text-xs font-medium text-white/70 tracking-tight flex items-center gap-2">
                  <SynapseXLogo className="w-3.5 h-3.5 text-white/80" />
                  <span>SynapseX OS v4.2 — [ {selectedCard.title} Telemetry ]</span>
                </div>

                {/* Status Dot */}
                <div className="flex items-center gap-1.5 text-[10px] text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="hidden sm:inline">LIVE BUS</span>
                </div>
              </div>

              {/* macOS Window Content Area */}
              <div className="p-6 sm:p-8 space-y-6">
                {/* Top Metrics Display */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10">
                  <div>
                    <span className="text-xs text-white/40 tracking-wider uppercase block mb-1">
                      Target Metric Value
                    </span>
                    <div className="text-4xl sm:text-5xl font-light text-white tracking-tight">
                      {selectedCard.value}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs self-start sm:self-auto">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span>{selectedCard.badge}</span>
                  </div>
                </div>

                {/* Cool Animated Waveform / Neural Spectrum Analyzer Graph */}
                <div>
                  <div className="flex items-center justify-between text-xs text-white/50 mb-3">
                    <span>BIO-NEURAL SPECTRUM ANALYZER</span>
                    <span>10.4 kHz Real-Time</span>
                  </div>
                  <div className="h-24 w-full bg-black/60 rounded-xl border border-white/10 p-3 flex items-end justify-between gap-1 overflow-hidden relative">
                    {[40, 65, 30, 85, 95, 50, 70, 90, 60, 45, 80, 100, 75, 55, 90, 65, 85, 40, 95, 70, 50, 85].map((h, idx) => (
                      <motion.div
                        key={idx}
                        animate={{ height: [`${h}%`, `${Math.max(20, (h + 35) % 100)}%`, `${h}%`] }}
                        transition={{ repeat: Infinity, duration: 1.5 + (idx % 4) * 0.3, ease: 'easeInOut' }}
                        className="flex-1 bg-gradient-to-t from-white/20 via-white/60 to-white rounded-t-sm"
                      />
                    ))}
                  </div>
                </div>

                {/* Technical Specifications Grid */}
                <div className="grid grid-cols-2 gap-3 pt-2">
                  {selectedCard.stats.map((st, i) => (
                    <div key={i} className="p-3 rounded-xl bg-white/[0.03] border border-white/10">
                      <div className="text-[10px] text-white/40 uppercase mb-0.5">{st.label}</div>
                      <div className="text-sm font-semibold text-white">{st.val}</div>
                    </div>
                  ))}
                </div>

                {/* Detailed Description */}
                <p className="text-xs text-white/60 leading-relaxed bg-white/[0.02] p-4 rounded-xl border border-white/5">
                  {selectedCard.desc} Interface protocol automatically handles cortical load balancing with sub-millisecond zero-friction pathways.
                </p>

                {/* macOS Control Action Bar */}
                <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                  <div className="text-[11px] text-white/40">
                    Press <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white">ESC</kbd> or click red button to exit
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => alert('Calibrating Neural Pathway... Signal Lock 100%')}
                      className="px-4 py-2 rounded-xl bg-white text-black text-xs font-semibold hover:bg-white/90 transition-all cursor-pointer shadow-lg"
                    >
                      Calibrate Signal
                    </button>
                    <button
                      onClick={() => setSelectedCard(null)}
                      className="px-4 py-2 rounded-xl bg-white/10 text-white text-xs hover:bg-white/20 transition-all cursor-pointer"
                    >
                      Close Window
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SECTION 4: CENTERED ADAPTIVE INTELLIGENCE LAYOUT (CHARACTER VIDEO CENTERED + STORY CENTERED) */}
      <section className="w-full min-h-screen relative overflow-hidden py-28 sm:py-36 px-6 bg-black flex items-center justify-center">
        <div className="max-w-4xl mx-auto w-full flex flex-col items-center text-center space-y-10 z-20">
          {/* Centered Character Video Frame */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.0 }}
            viewport={{ once: true, amount: 0.3 }}
            className="w-full max-w-2xl rounded-3xl overflow-hidden border border-white/25 shadow-[0_0_90px_rgba(255,255,255,0.22)] group"
          >
            <div className="w-full h-[400px] sm:h-[480px] relative overflow-hidden">
              <video
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260622_095750_32a52ce0-2005-45c9-9093-41f03fde9530.mp4"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-xs text-white/80 font-mono">
                <span>CHAPTER III // ADAPTIVE AI</span>
                <span>72-HR SYNC</span>
              </div>
            </div>
          </motion.div>

          {/* Centered Story Card & 4 Feature Pillars Grid */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 1.0 }}
            viewport={{ once: true, amount: 0.3 }}
            className="w-full bg-black/80 backdrop-blur-2xl border border-white/20 rounded-3xl p-8 sm:p-12 md:p-14 text-center shadow-2xl space-y-6"
          >
            <div className="flex items-center justify-center gap-2 text-xs sm:text-sm text-white/40 tracking-[0.2em] uppercase font-mono">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-400 animate-pulse" />
              <span>Chapter III: The Adaptive Loop</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-white leading-tight tracking-tight max-w-3xl mx-auto">
              Continuous Machine Learning Baseline Sync
            </h2>

            <p className="text-white/60 text-base sm:text-lg leading-relaxed font-normal max-w-2xl mx-auto">
              The system learns your neural baseline within 72 hours. From there, every cognitive state is mapped, predicted, and optimized in real time. Closed-loop adjustments create seamless harmony between mind and machine.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left pt-2">
              {[
                { title: 'Cortical Mapping', desc: 'Real-time spatial reconstruction of active neural regions.' },
                { title: 'Signal Isolation', desc: 'Separates cognitive intent from biological noise.' },
                { title: 'State Prediction', desc: 'Anticipates cognitive transitions before they occur.' },
                { title: 'Loop Feedback', desc: 'Closed-loop adjustment based on outcome correlation.' },
              ].map((item) => (
                <div key={item.title} className="p-5 rounded-2xl bg-white/[0.05] border border-white/15 hover:border-white/40 transition-colors">
                  <h3 className="text-white text-sm font-semibold mb-1.5">{item.title}</h3>
                  <p className="text-white/50 text-xs leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* MERGED SIDE-BY-SIDE ARCHITECTURE & FOOTER SECTION */}
      <footer className="w-full bg-black relative border-t border-white/10 overflow-hidden py-24 sm:py-32 px-6">
        <div className="max-w-7xl mx-auto w-full grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16 items-center z-20">
          {/* Half 1 (LEFT): Character Video #5 */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 1.0 }}
            viewport={{ once: true, amount: 0.3 }}
            className="relative rounded-3xl overflow-hidden border border-white/20 shadow-[0_0_80px_rgba(255,255,255,0.18)] group"
          >
            <div className="w-full h-[460px] sm:h-[540px] lg:h-[600px] relative overflow-hidden">
              <video
                autoPlay
                muted
                loop
                playsInline
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260622_080203_fd7f4f85-3a86-4837-8192-85e7bfe68e75.mp4"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/20" />
              <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-xs text-white/80 font-mono">
                <span>SYNAPSE SYSTEM // FOOTER</span>
                <span>© 2026 SYNAPSEX</span>
              </div>
            </div>
          </motion.div>

          {/* Half 2 (RIGHT): Architecture 3-Layer System & SynapseX Brand Footer */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 1.0 }}
            viewport={{ once: true, amount: 0.3 }}
            className="space-y-8"
          >
            {/* Header */}
            <div className="space-y-3">
              <span className="text-white/40 text-xs tracking-[0.2em] uppercase font-mono block">
                SYSTEM ARCHITECTURE // THREE LAYERS
              </span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-light text-white tracking-tight">
                Three layers. Zero friction.
              </h2>
              <p className="text-white/50 text-sm sm:text-base leading-relaxed font-normal">
                Sensor layer captures raw bioelectric signals. Processing layer isolates intent. Interface layer delivers structured output.
              </p>
            </div>

            {/* 3 Stacked Layer Cards */}
            <div className="space-y-3.5 pt-2">
              {[
                { layer: 'Layer 1', label: 'Capture', desc: 'High-density dry bioelectric sensor array' },
                { layer: 'Layer 2', label: 'Process', desc: 'Real-time noise filtering & intent extraction' },
                { layer: 'Layer 3', label: 'Interface', desc: 'Low-latency bio-digital output stream' },
              ].map((card) => (
                <div
                  key={card.layer}
                  className="w-full p-4 sm:p-5 border border-white/15 rounded-2xl flex items-center justify-between bg-white/[0.04] hover:border-white/40 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-white/30 text-xs tracking-widest uppercase font-mono">{card.layer}</span>
                    <span className="text-white text-base font-semibold">{card.label}</span>
                  </div>
                  <span className="text-white/50 text-xs hidden sm:inline font-mono">{card.desc}</span>
                </div>
              ))}
            </div>

            {/* Brand Footer Info & Copyright */}
            <div className="pt-8 border-t border-white/10 space-y-4">
              <div className="flex items-center gap-2">
                <SynapseXLogo className="w-4 h-4 text-white/80" />
                <span className="text-base font-medium text-white/80 tracking-tight">SynapseX</span>
              </div>
              <p className="text-white/40 text-xs sm:text-sm leading-relaxed max-w-md font-normal">
                The next evolution of human-machine interaction. Built for those who refuse to be limited by biology alone.
              </p>
              <span className="text-white/25 text-xs font-mono block pt-2">
                © 2026 SynapseX Labs. All rights reserved.
              </span>
            </div>
          </motion.div>
        </div>
      </footer>
    </div>
  );
}
